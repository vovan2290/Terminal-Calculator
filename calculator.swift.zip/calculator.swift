#!/usr/bin/swift

// calculator Volodymyr
import Foundation

var operationSymbols = ["-","+","/","*"]
var firstNum = 0.0
var secondNum = 0.0
var result = 0.0
var operation: String?

var userInputOperation: String?
var userFirstNumberInput: String?
var userSecondNumberInput: String?



func getOperationSymbol() {
    print("What operation woul you like to perform?")
    
    userInputOperation = readLine()
    
    if operationSymbols.contains(userInputOperation!) {
        operation = userInputOperation
        } else {
        print("That is not a valid operation")
        getOperationSymbol()
        }
    }


func getFirstNumber() {
    print("Please enter the first number")
    
    userFirstNumberInput = readLine()
    
    if let userFirstNumberInput = Double(userFirstNumberInput!) {
        firstNum = userFirstNumberInput
    } else {
        print("That is not a number")
        getFirstNumber()
    }
}


func getSecondNumber() {
    print("Please enter the second number")
    
    userSecondNumberInput = readLine()
    
    if let userSecondNumberInput = Double(userSecondNumberInput!) {
        secondNum = userSecondNumberInput
        
    } else {
        print("That is not a number")
        getSecondNumber()
    }
}


func calculateResult() {
    switch operation {
    
case "-":
    result = firstNum - secondNum
        print("The result of operation is \(result)")
    
case "+":
    result = firstNum + secondNum
        print("The result of operation is \(result)")
    
case "/":
    result = firstNum / secondNum
    print("The result of operation is \(result)")
    
case "*":
    result = firstNum * secondNum
    print("The result of operation is \(result)")

default:
    print("I'm sorry but I'm so tired please try again")
    getOperationSymbol()
 }
    
}
     
func moreCalculationsOrNot() {
    print("Would you like to make more calculations? Type Yes if continue")
    let moreCalc = readLine()
    if moreCalc == "yes" || moreCalc == "Yes" || moreCalc == "YES"{
        newCalculation()
    } else {
        print("Bye Bye")
    }
}

func newCalculation() {
    print("Let's make more calculations")
    doAllOperations()
}

func doAllOperations(){
    getOperationSymbol()
    getFirstNumber()
    getSecondNumber()
    calculateResult()
    moreCalculationsOrNot()
}

doAllOperations()
